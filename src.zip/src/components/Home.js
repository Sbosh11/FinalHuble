import "./Home.css";

function Home() {
  return (
    <div className="home">
      <h1>HUBLE | FRONT-END DEVELOPER ASSESSMENT</h1>
      <p>By: Sibongile Thanjekwayo</p>
    </div>
  );
}
export default Home;
